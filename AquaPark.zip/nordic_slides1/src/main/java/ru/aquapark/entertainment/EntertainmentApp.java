package ru.aquapark.entertainment;


import ru.aquapark.entertainment.config.StartConfig;

import ru.aquapark.entertainment.model.Person;

import ru.aquapark.entertainment.model.Slides;
import ru.aquapark.entertainment.model.SlidesList;

import java.util.ArrayList;
import java.util.Scanner;




public class EntertainmentApp {
    public static void main(String[] args) {
        StartConfig.start();
    }
}
